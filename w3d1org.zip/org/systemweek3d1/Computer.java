package org.systemweek3d1;



public class Computer
{
	public void computerModel() {
		System.out.println("The model name is HP");
	}
	public static void main(String[] args) {
		Computer model=new Computer();
		model.computerModel();
		
		
	}
}