package org.systemweek3d1;

public class Desktop extends Computer {
	public void desktopSize()
	{
		System.out.println("Its a standard size");
	}
public static void main(String[] args) {
	Desktop size=new Desktop();
	size.computerModel();
	size.desktopSize();
}
}
