package w3d1org.college;

public class College {
//  Methods   :collegeName(),collegeCode(),collegeRank()
	public void collegeName()
	{
		System.out.println("College name is St.Peters");
	}
	protected void collegeCode()
	{
		System.out.println("The college code is 6756454");
	}
	public void collegeRank()
	{
		System.out.println("The collegerank -26");
	}
	
	public static void main(String[] args) {
		
		College details=new College();
		details.collegeName();
		details.collegeCode();
		details.collegeRank();
		
	}
	
	
	
}



