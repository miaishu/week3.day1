package w3d1org.department;

import w3d1org.college.College;

public class Department extends College
{
	public void deptName() {
		System.out.println("The department name is EIE");
	}
public static void main(String[] args) {
	
	Department details1=new Department();
	
	details1.collegeName();
	details1.collegeCode();
	details1.collegeRank();
	details1.deptName();
	
	
}
}
