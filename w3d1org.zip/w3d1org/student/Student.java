package w3d1org.student;

import w3d1org.department.Department;

public class Student extends Department{
	//Methods   :studentName(),studentDept(),studentId()
public void studentName() {
	System.out.println("Ashley");
	}
private void studentDept() {
	System.out.println("Dept Name-Aero");
}
protected void studentId() {
	System.out.println("ID is 123 ");
}

public static void main(String[] args) {

	Student bio=new Student();
	bio.collegeName();
	bio.collegeCode();
	bio.collegeRank();
	bio.deptName();
	bio.studentName();
	bio.studentDept();
	bio.studentId();
	
	
}


}
